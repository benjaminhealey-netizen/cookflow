// netlify/functions/searchRecipes.js
// Searches Spoonacular first, falls back to OpenAI generation if no results
// Accepts: POST { prompt, filters, count }
// Returns: { recipes: [...], source: 'spoonacular' | 'ai' }

const DIET_MAP = {
  'vegetarian': 'vegetarian',
  'vegan': 'vegan',
  'gluten-free': 'gluten free',
  'dairy-free': 'dairy free',
  'nut-free': null, // handled via intolerances
  'shellfish-free': null,
  'low-carb': 'paleo', // closest Spoonacular equivalent
  'halal': null,
  'kosher': null,
};

const INTOLERANCE_MAP = {
  'gluten-free': 'gluten',
  'dairy-free': 'dairy',
  'nut-free': 'tree nut,peanut',
  'shellfish-free': 'shellfish',
};

exports.handler = async function (event) {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  let prompt, filters, count;
  try {
    const body = JSON.parse(event.body || '{}');
    prompt = body.prompt || '';
    filters = Array.isArray(body.filters) ? body.filters : [];
    count = Math.min(body.count || 3, 5);
  } catch {
    return { statusCode: 400, body: JSON.stringify({ error: 'Invalid JSON' }) };
  }

  const spoonKey = process.env.SPOONACULAR_API_KEY;
  const openaiKey = process.env.OPENAI_API_KEY;

  // ---- Try Spoonacular first ----
  if (spoonKey) {
    try {
      const spoonRecipes = await searchSpoonacular(prompt, filters, count, spoonKey);
      if (spoonRecipes && spoonRecipes.length > 0) {
        return {
          statusCode: 200,
          headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
          body: JSON.stringify({ recipes: spoonRecipes, source: 'spoonacular' }),
        };
      }
    } catch (err) {
      console.error('Spoonacular error:', err.message);
      // Fall through to AI
    }
  }

  // ---- Fallback: OpenAI generation ----
  if (!openaiKey) {
    return { statusCode: 500, body: JSON.stringify({ error: 'No API keys configured' }) };
  }

  try {
    const aiRecipes = await generateMultipleAI(prompt, filters, count, openaiKey);
    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ recipes: aiRecipes, source: 'ai' }),
    };
  } catch (err) {
    console.error('AI fallback error:', err.message);
    return { statusCode: 502, body: JSON.stringify({ error: 'Failed to fetch recipes' }) };
  }
};

// ==================== SPOONACULAR ====================
async function searchSpoonacular(prompt, filters, count, apiKey) {
  // Build diet and intolerance params
  const diets = filters
    .map(f => DIET_MAP[f])
    .filter(Boolean);

  const intolerances = filters
    .flatMap(f => INTOLERANCE_MAP[f] ? INTOLERANCE_MAP[f].split(',') : [])
    .filter(Boolean);

  // Extract keywords from prompt — remove filler words
  const stopWords = new Set(['a','an','the','make','me','i','want','something','some','please','give','create','recipe','for','with','and','or','that','is','are','very','really','dish','food','meal','cook','cooking']);
  const keywords = prompt
    .toLowerCase()
    .replace(/[^a-z0-9 ]/g, '')
    .split(' ')
    .filter(w => w.length > 2 && !stopWords.has(w))
    .slice(0, 4)
    .join(' ');

  const params = new URLSearchParams({
    apiKey,
    query: keywords || 'dinner',
    number: count * 2, // fetch extra for variety
    addRecipeInformation: true,
    fillIngredients: false,
    instructionsRequired: true,
    ...(diets.length > 0 && { diet: diets[0] }), // Spoonacular only supports one diet
    ...(intolerances.length > 0 && { intolerances: intolerances.join(',') }),
  });

  const url = `https://api.spoonacular.com/recipes/complexSearch?${params}`;
  const res = await fetch(url);

  if (!res.ok) {
    const err = await res.text();
    throw new Error(`Spoonacular ${res.status}: ${err}`);
  }

  const data = await res.json();
  if (!data.results || data.results.length === 0) return [];

  // Shuffle for variety and take what we need
  const shuffled = data.results.sort(() => Math.random() - 0.5).slice(0, count);

  // Fetch full recipe details for each
  const detailed = await Promise.all(
    shuffled.map(r => fetchSpoonacularRecipe(r.id, apiKey))
  );

  return detailed.filter(Boolean);
}

async function fetchSpoonacularRecipe(id, apiKey) {
  try {
    const res = await fetch(
      `https://api.spoonacular.com/recipes/${id}/information?apiKey=${apiKey}&includeNutrition=false`
    );
    if (!res.ok) return null;
    const r = await res.json();

    // Extract steps
    let steps = [];
    if (r.analyzedInstructions && r.analyzedInstructions.length > 0) {
      steps = r.analyzedInstructions[0].steps.map(s => s.step);
    }
    if (steps.length === 0) return null;

    // Extract ingredients
    const ingredients = (r.extendedIngredients || []).map(ing =>
      `${ing.amount ? ing.amount + ' ' : ''}${ing.unit ? ing.unit + ' ' : ''}${ing.name}`.trim()
    );

    // Determine dietary tags
    const dietaryTags = [];
    if (r.vegetarian) dietaryTags.push('vegetarian');
    if (r.vegan) dietaryTags.push('vegan');
    if (r.glutenFree) dietaryTags.push('gluten-free');
    if (r.dairyFree) dietaryTags.push('dairy-free');

    // Pick emoji based on dish type
    const emoji = pickEmoji(r.dishTypes || [], r.title);

    // Clean description from summary (strip HTML)
    const description = (r.summary || '')
      .replace(/<[^>]+>/g, '')
      .replace(/\s+/g, ' ')
      .split('.')[0]
      .trim()
      .substring(0, 140) + '.';

    return {
      title: r.title,
      description,
      ingredients,
      steps,
      notes: r.tips ? [r.tips] : [],
      dietaryTags,
      emoji,
      sourceUrl: r.sourceUrl || null,
      spoonacularId: r.id,
    };
  } catch (err) {
    console.error('fetchSpoonacularRecipe error:', err.message);
    return null;
  }
}

function pickEmoji(dishTypes, title) {
  const t = (dishTypes.join(' ') + ' ' + title).toLowerCase();
  if (t.includes('pasta') || t.includes('noodle')) return '🍝';
  if (t.includes('soup') || t.includes('stew')) return '🍲';
  if (t.includes('salad')) return '🥗';
  if (t.includes('burger') || t.includes('sandwich')) return '🥪';
  if (t.includes('pizza')) return '🍕';
  if (t.includes('taco') || t.includes('mexican')) return '🌮';
  if (t.includes('sushi') || t.includes('japanese')) return '🍱';
  if (t.includes('curry') || t.includes('indian')) return '🍛';
  if (t.includes('breakfast') || t.includes('egg')) return '🍳';
  if (t.includes('dessert') || t.includes('cake') || t.includes('sweet')) return '🧁';
  if (t.includes('chicken')) return '🍗';
  if (t.includes('fish') || t.includes('seafood')) return '🐟';
  if (t.includes('steak') || t.includes('beef')) return '🥩';
  if (t.includes('rice')) return '🍚';
  if (t.includes('wrap')) return '🌯';
  return ['🍽️','🥘','🫕','🍜','🥙'][Math.floor(Math.random() * 5)];
}

// ==================== AI FALLBACK ====================
async function generateMultipleAI(prompt, filters, count, apiKey) {
  const filterInstructions = filters.length > 0
    ? `\nCRITICAL - strictly follow ALL these dietary restrictions:\n${filters.map(f => `- ${f}`).join('\n')}`
    : '';

  // Generate variety by adding different style modifiers
  const styleVariants = [
    'Make it restaurant-quality and impressive.',
    'Make it a quick weeknight version.',
    'Give it an international twist.',
    'Make it a cozy homestyle version.',
    'Make it a healthy lighter version.',
  ];

  const promises = Array.from({ length: count }, (_, i) => {
    const style = styleVariants[i % styleVariants.length];
    return generateSingleAI(`${prompt}. ${style}`, filters, filterInstructions, apiKey);
  });

  const results = await Promise.all(promises);
  return results.filter(Boolean);
}

async function generateSingleAI(prompt, filters, filterInstructions, apiKey) {
  const systemPrompt = `You are a world-class chef. Respond ONLY with a valid JSON object, no markdown.

{
  "title": "Recipe Name",
  "description": "1-2 sentence description.",
  "ingredients": ["quantity unit ingredient"],
  "steps": ["Step instruction."],
  "notes": ["Tip."],
  "dietaryTags": ["vegetarian", "vegan", "gluten-free", "dairy-free", "nut-free", "shellfish-free", "low-carb", "halal", "kosher"]
}

Only include dietaryTags the recipe genuinely qualifies for.${filterInstructions}
Raw JSON only. No extra text.`;

  try {
    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        temperature: 0.9,
        max_tokens: 800,
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: `Recipe for: ${prompt}` },
        ],
      }),
    });

    if (!res.ok) return null;
    const data = await res.json();
    const raw = data.choices?.[0]?.message?.content || '';
    const cleaned = raw.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/```\s*$/i, '').trim();
    const recipe = JSON.parse(cleaned);
    if (!recipe.title || !recipe.ingredients || !recipe.steps) return null;
    if (!Array.isArray(recipe.notes)) recipe.notes = [];
    if (!Array.isArray(recipe.dietaryTags)) recipe.dietaryTags = [];
    return recipe;
  } catch {
    return null;
  }
}
