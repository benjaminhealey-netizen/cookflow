// netlify/functions/generateRecipe.js
// Accepts: POST { prompt: string, filters: string[] }
// Returns: recipe JSON with dietaryTags field

exports.handler = async function (event) {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  let prompt, filters;
  try {
    const body = JSON.parse(event.body || '{}');
    prompt = body.prompt;
    filters = Array.isArray(body.filters) ? body.filters : [];
  } catch {
    return { statusCode: 400, body: JSON.stringify({ error: 'Invalid JSON body' }) };
  }

  if (!prompt || !prompt.trim()) {
    return { statusCode: 400, body: JSON.stringify({ error: 'Missing prompt' }) };
  }

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return { statusCode: 500, body: JSON.stringify({ error: 'OpenAI API key not configured' }) };
  }

  // Build dietary restriction instructions
  const filterInstructions = filters.length > 0
    ? `\n\nCRITICAL DIETARY RESTRICTIONS — you MUST follow ALL of these strictly. Never include any ingredient that violates them:\n${filters.map(f => `- ${f}`).join('\n')}\n\nIf a restriction is active, scan every single ingredient and step to ensure compliance. Do not suggest substitutions that still violate the restriction.`
    : '';

  const systemPrompt = `You are a world-class chef and recipe writer. When given a cooking request, respond ONLY with a valid JSON object — no markdown fences, no preamble, no explanation.

The JSON must follow this EXACT structure:
{
  "title": "Recipe Name",
  "description": "One to two sentence evocative description.",
  "ingredients": ["quantity ingredient", "..."],
  "steps": ["Complete cooking instruction.", "..."],
  "notes": ["Optional tip or variation.", "..."],
  "dietaryTags": ["vegetarian", "gluten-free", "..."]
}

Rules:
- title: short appetizing name (string)
- description: 1-2 sentences, vivid and enticing (string)
- ingredients: 4-14 items, each string includes quantity (array of strings)
- steps: 4-10 clear actionable cooking steps, each a complete sentence (array of strings)
- notes: 1-3 helpful tips or serving suggestions (array of strings, can be [])
- dietaryTags: list ALL applicable tags from this set that the recipe qualifies for:
  ["vegetarian", "vegan", "gluten-free", "dairy-free", "nut-free", "shellfish-free", "low-carb", "halal", "kosher"]
  Only include a tag if the recipe GENUINELY qualifies. Be accurate.${filterInstructions}

Respond ONLY with raw JSON. No markdown. No extra text.`;

  const userMessage = `Create a recipe for: ${prompt.trim()}`;

  try {
    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        temperature: 0.75,
        max_tokens: 1000,
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userMessage },
        ],
      }),
    });

    if (!res.ok) {
      const err = await res.text();
      console.error('OpenAI error:', res.status, err);
      return { statusCode: 502, body: JSON.stringify({ error: 'OpenAI request failed', status: res.status }) };
    }

    const data = await res.json();
    const raw = data.choices?.[0]?.message?.content;
    if (!raw) return { statusCode: 502, body: JSON.stringify({ error: 'Empty OpenAI response' }) };

    const cleaned = raw.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/```\s*$/i, '').trim();

    let recipe;
    try {
      recipe = JSON.parse(cleaned);
    } catch {
      console.error('JSON parse failed. Raw:', raw);
      return { statusCode: 502, body: JSON.stringify({ error: 'Failed to parse recipe JSON' }) };
    }

    if (!recipe.title || !Array.isArray(recipe.ingredients) || !Array.isArray(recipe.steps)) {
      return { statusCode: 502, body: JSON.stringify({ error: 'Recipe missing required fields' }) };
    }

    if (!Array.isArray(recipe.notes)) recipe.notes = [];
    if (!Array.isArray(recipe.dietaryTags)) recipe.dietaryTags = [];

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify(recipe),
    };
  } catch (err) {
    console.error('Function error:', err);
    return { statusCode: 500, body: JSON.stringify({ error: 'Internal error', details: err.message }) };
  }
};
