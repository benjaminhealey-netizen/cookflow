// netlify/functions/scanFridge.js
// Accepts: POST { image: base64string }
// Returns: { ingredients: string[] }

exports.handler = async function (event) {
  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: JSON.stringify({ error: 'Method not allowed' }) };
  }

  let image;
  try {
    const body = JSON.parse(event.body || '{}');
    image = body.image;
  } catch {
    return { statusCode: 400, body: JSON.stringify({ error: 'Invalid JSON body' }) };
  }

  if (!image || typeof image !== 'string') {
    return { statusCode: 400, body: JSON.stringify({ error: 'Missing image data' }) };
  }

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return { statusCode: 500, body: JSON.stringify({ error: 'OpenAI API key not configured' }) };
  }

  const systemPrompt = `You are a culinary ingredient detection assistant. You will be shown a photo of a fridge, pantry, or collection of ingredients.

Your job is to identify every food ingredient visible in the image and return them as a JSON array.

Respond ONLY with a valid JSON object in this exact format:
{
  "ingredients": ["ingredient 1", "ingredient 2", "ingredient 3", ...]
}

Rules:
- List each ingredient as a simple name: "chicken breast", "garlic", "cheddar cheese", "spinach", etc.
- Be specific where visible: "cherry tomatoes" not just "tomatoes" if that's what you see
- Include condiments, sauces, and beverages only if clearly food-usable (e.g. "soy sauce", "olive oil")
- Ignore non-food items, containers without visible contents, and packaging you can't identify
- If the image is unclear or you can't see any ingredients, return: { "ingredients": [] }
- Return 3-20 ingredients maximum
- No markdown. No extra text. Raw JSON only.`;

  try {
    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        max_tokens: 500,
        messages: [
          { role: 'system', content: systemPrompt },
          {
            role: 'user',
            content: [
              {
                type: 'image_url',
                image_url: {
                  url: `data:image/jpeg;base64,${image}`,
                  detail: 'low',
                },
              },
              {
                type: 'text',
                text: 'What food ingredients do you see in this image? Return JSON only.',
              },
            ],
          },
        ],
      }),
    });

    if (!res.ok) {
      const err = await res.text();
      console.error('OpenAI vision error:', res.status, err);
      return { statusCode: 502, body: JSON.stringify({ error: 'OpenAI vision request failed', status: res.status }) };
    }

    const data = await res.json();
    const raw = data.choices?.[0]?.message?.content;
    if (!raw) return { statusCode: 502, body: JSON.stringify({ error: 'Empty OpenAI response' }) };

    const cleaned = raw.replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/```\s*$/i, '').trim();

    let result;
    try {
      result = JSON.parse(cleaned);
    } catch {
      console.error('Vision JSON parse failed. Raw:', raw);
      return { statusCode: 502, body: JSON.stringify({ error: 'Failed to parse ingredient JSON' }) };
    }

    if (!Array.isArray(result.ingredients)) result.ingredients = [];

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ ingredients: result.ingredients }),
    };
  } catch (err) {
    console.error('scanFridge error:', err);
    return { statusCode: 500, body: JSON.stringify({ error: 'Internal error', details: err.message }) };
  }
};
