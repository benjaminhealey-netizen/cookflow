/* ============================================================
   CookFlow v3 — app.js
   Personalized feed, real images, nutrition, dark/light, print
   ============================================================ */

const state = {
  activeFilters: new Set(),
  feedRecipes: [],
  feedIndex: 0,
  feedLoading: false,
  currentRecipe: null,
  cookStep: 0,
  cameraStream: null,
  cameraFacing: 'environment',
  detectedIngredients: [],
  _currentPrompt: '',
  _cookSlides: [],
  cookHistory: [],       // titles of recipes the user has cooked
  theme: 'dark',
};

const FOOD_EMOJIS = ['🍝','🍜','🥘','🍲','🥗','🍱','🌮','🥙','🍛','🫕','🥩','🍗','🫔','🥞','🧆','🍳','🥚','🌯','🍚','🫛','🍠','🧁','🥣','🍤','🥓','🍣','🥑','🧀','🌽','🥦','🍕','🥪','🌶️','🫚','🧄','🧅','🥐','🫙','🍖','🥜'];

const BG_COLORS = [
  'linear-gradient(135deg,#1a0a00,#2d1100)',
  'linear-gradient(135deg,#001a0d,#002914)',
  'linear-gradient(135deg,#0a0a1a,#11112d)',
  'linear-gradient(135deg,#1a000d,#2d0012)',
  'linear-gradient(135deg,#0d1a00,#142900)',
  'linear-gradient(135deg,#1a1000,#2d1a00)',
  'linear-gradient(135deg,#001418,#002830)',
  'linear-gradient(135deg,#180018,#2a002a)',
];

// Unsplash source for food images — free, no key needed
function getImageUrl(title) {
  const keywords = title
    .toLowerCase()
    .replace(/[^a-z0-9 ]/g, '')
    .split(' ')
    .filter(w => w.length > 2)
    .slice(0, 3)
    .join(',');
  return `https://source.unsplash.com/featured/800x1000/?${encodeURIComponent(keywords + ',food')}`;
}

document.addEventListener('DOMContentLoaded', () => {
  loadTheme();
  loadCookHistory();
  bindHomeEvents();
  bindFeedEvents();
  bindCookEvents();
  bindSheetEvents();
  bindPantryEvents();
  bindFridgeEvents();
  bindIngredientConfirmEvents();
  restoreFilters();
});

// ==================== THEME ====================
function loadTheme() {
  const saved = localStorage.getItem('cf3_theme') || 'dark';
  applyTheme(saved);
}

function applyTheme(theme) {
  state.theme = theme;
  document.documentElement.setAttribute('data-theme', theme);
  document.getElementById('meta-theme-color').content = theme === 'dark' ? '#080808' : '#f5f0e8';
  localStorage.setItem('cf3_theme', theme);
}

// ==================== COOK HISTORY ====================
function loadCookHistory() {
  try { state.cookHistory = JSON.parse(localStorage.getItem('cf3_history') || '[]'); }
  catch { state.cookHistory = []; }
}

function addToHistory(recipe) {
  state.cookHistory = state.cookHistory.filter(t => t !== recipe.title);
  state.cookHistory.unshift(recipe.title);
  if (state.cookHistory.length > 30) state.cookHistory = state.cookHistory.slice(0,30);
  localStorage.setItem('cf3_history', JSON.stringify(state.cookHistory));
}

function buildPersonalizedPrompt(basePrompt) {
  if (state.cookHistory.length < 3) return basePrompt;
  const recent = state.cookHistory.slice(0,5).join(', ');
  return `${basePrompt}. The user has previously enjoyed: ${recent}. Suggest something in a similar style but with variety — don't repeat the exact same dishes.`;
}

// ==================== SCREEN ====================
function showScreen(name, from = null) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  const el = document.getElementById(`screen-${name}`);
  if (el) el.classList.add('active');
}

// ==================== HOME ====================
function bindHomeEvents() {
  document.getElementById('theme-toggle-btn').addEventListener('click', () => {
    applyTheme(state.theme === 'dark' ? 'light' : 'dark');
  });

  document.getElementById('search-go-btn').addEventListener('click', () => {
    const q = document.getElementById('main-search').value.trim();
    if (!q) { showToast('Type something first!'); return; }
    startFeedWithPrompt(q);
  });
  document.getElementById('main-search').addEventListener('keydown', e => {
    if (e.key === 'Enter') document.getElementById('search-go-btn').click();
  });

  document.getElementById('start-feed-btn').addEventListener('click', () => {
    const prompts = [
      'popular dinner recipes','best lunch ideas','easy weeknight meals',
      'healthy bowls and salads','comfort food classics','international street food',
      'quick 20 minute dinners','high protein meals','mediterranean cuisine',
      'restaurant quality pasta','asian fusion recipes','vegetable forward dishes',
      'one pan meals','slow cooker recipes','grilled dishes',
    ];
    const p = prompts[Math.floor(Math.random() * prompts.length)];
    startFeedWithPrompt(p);
  });

  document.querySelectorAll('.qcat:not(.pantry-qcat)').forEach(btn => {
    btn.addEventListener('click', () => startFeedWithPrompt(btn.dataset.prompt));
  });

  document.getElementById('pantry-mode-btn').addEventListener('click', () => showScreen('pantry'));
  document.getElementById('saved-btn').addEventListener('click', () => { renderSavedScreen(); showScreen('saved'); });
  document.getElementById('fridge-scan-btn').addEventListener('click', () => openFridgeScan());

  document.querySelectorAll('#filters-grid .filter-pill').forEach(pill => {
    pill.addEventListener('click', () => {
      const f = pill.dataset.filter;
      if (state.activeFilters.has(f)) { state.activeFilters.delete(f); pill.classList.remove('active'); }
      else { state.activeFilters.add(f); pill.classList.add('active'); }
      saveFilters();
    });
  });

  document.querySelectorAll('[data-back]').forEach(el => {
    el.addEventListener('click', () => showScreen(el.dataset.back));
  });
}

// ==================== FEED ====================
async function startFeedWithPrompt(prompt) {
  state.feedRecipes = [];
  state.feedIndex = 0;
  state.feedLoading = false;
  state._currentPrompt = prompt;

  showScreen('feed');
  renderFeedContainer();
  document.getElementById('swipe-hint').style.display = 'flex';
  document.getElementById('feed-loading').classList.remove('hidden');

  await loadRecipeBatch(prompt, 3);
}

async function loadRecipeBatch(prompt, count = 3) {
  if (state.feedLoading) return;
  state.feedLoading = true;
  try {
    const personalizedPrompt = buildPersonalizedPrompt(prompt);
    const filters = Array.from(state.activeFilters);
    const res = await fetch('/api/searchRecipes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt: personalizedPrompt, filters, count }),
    });
    if (!res.ok) throw new Error(`API ${res.status}`);
    const data = await res.json();
    if (!data.recipes?.length) throw new Error('No recipes');

    const existing = new Set(state.feedRecipes.map(r => r.title));
    let ci = state.feedRecipes.length;

    data.recipes.forEach(r => {
      if (existing.has(r.title)) return;
      existing.add(r.title);
      r.emoji = r.emoji || randomEmoji();
      r.bgColor = BG_COLORS[ci % BG_COLORS.length];
      r._prompt = prompt;
      r._source = data.source;
      ci++;
      state.feedRecipes.push(r);
    });

    document.getElementById('feed-loading').classList.add('hidden');
    renderFeedCards();
    if (data.source === 'spoonacular') showToast(`${data.recipes.length} real recipes found ✓`);
  } catch (err) {
    console.error(err);
    document.getElementById('feed-loading').classList.add('hidden');
    showToast('Could not load recipes. Try again!');
  } finally {
    state.feedLoading = false;
  }
}

function renderFeedContainer() {
  document.getElementById('feed-container').innerHTML = '';
}

function renderFeedCards() {
  const container = document.getElementById('feed-container');
  container.innerHTML = '';
  state.feedRecipes.forEach((r, i) => container.appendChild(createFeedCard(r, i)));
  updateFeedPositions();
}

function createFeedCard(recipe, index) {
  const saved = isRecipeSaved(recipe);
  const tagsHtml = (recipe.dietaryTags || []).slice(0,3).map(t => `<span class="dietary-tag">${t}</span>`).join('');
  const sourceBadge = recipe._source === 'spoonacular'
    ? `<span class="source-badge">🔍 Real Recipe</span>`
    : `<span class="source-badge">✨ AI Generated</span>`;

  const div = document.createElement('div');
  div.className = 'recipe-card-full';
  div.dataset.index = index;

  div.innerHTML = `
    <div class="card-bg">
      <div class="card-bg-color" style="background:${recipe.bgColor}"></div>
      <div class="card-bg-img" id="card-img-${index}"></div>
      <div class="card-bg-gradient"></div>
    </div>
    <div class="card-food-visual" id="card-emoji-${index}">${recipe.emoji}</div>
    <div class="card-content">
      <div class="card-meta-row">
        ${sourceBadge}
        ${tagsHtml ? `<div class="card-tags">${tagsHtml}</div>` : ''}
      </div>
      <div class="card-title">${recipe.title}</div>
      <div class="card-desc">${recipe.description}</div>
      <div class="card-actions">
        <button class="cook-this-btn">Cook This →</button>
        <button class="card-action-btn nutrition-card-btn" title="Nutrition">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2a9 9 0 0 1 9 9c0 5-9 13-9 13S3 16 3 11a9 9 0 0 1 9-9z"/><circle cx="12" cy="11" r="3"/></svg>
        </button>
        <button class="card-action-btn print-card-btn" title="Print">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
        </button>
        <button class="card-action-btn remix-card-btn" title="Remix">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>
        </button>
        <button class="card-action-btn save-card-btn ${saved ? 'saved-active' : ''}" title="Save">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="${saved ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>
        </button>
      </div>
    </div>`;

  // Load real image from Unsplash
  loadCardImage(recipe, index);

  div.querySelector('.cook-this-btn').addEventListener('click', e => { e.stopPropagation(); state.currentRecipe = state.feedRecipes[index]; startCookMode(); });
  div.querySelector('.nutrition-card-btn').addEventListener('click', e => { e.stopPropagation(); openNutritionSheet(state.feedRecipes[index]); });
  div.querySelector('.print-card-btn').addEventListener('click', e => { e.stopPropagation(); printRecipe(state.feedRecipes[index]); });
  div.querySelector('.remix-card-btn').addEventListener('click', e => { e.stopPropagation(); state.currentRecipe = state.feedRecipes[index]; openRemixSheet(); });
  div.querySelector('.save-card-btn').addEventListener('click', e => { e.stopPropagation(); toggleSaveRecipe(state.feedRecipes[index]); renderFeedCards(); });

  return div;
}

function loadCardImage(recipe, index) {
  const imgUrl = getImageUrl(recipe.title);
  const img = new Image();
  img.onload = () => {
    const bgEl = document.getElementById(`card-img-${index}`);
    const emojiEl = document.getElementById(`card-emoji-${index}`);
    if (bgEl) {
      bgEl.style.backgroundImage = `url(${img.src})`;
      bgEl.classList.add('loaded');
    }
    if (emojiEl) emojiEl.classList.add('hidden-by-img');
  };
  img.onerror = () => {
    // Keep emoji fallback — do nothing
  };
  // Small delay so card renders first
  setTimeout(() => { img.src = imgUrl; }, 100);
}

function updateFeedPositions() {
  document.querySelectorAll('.recipe-card-full').forEach(card => {
    const i = parseInt(card.dataset.index);
    card.classList.remove('above','current','below','dragging');
    if (i < state.feedIndex) card.classList.add('above');
    else if (i === state.feedIndex) card.classList.add('current');
    else card.classList.add('below');
  });
}

// ==================== FEED SWIPE ====================
function bindFeedEvents() {
  const container = document.getElementById('feed-container');
  let startY = 0, currentY = 0, dragging = false;

  container.addEventListener('touchstart', e => { startY = e.touches[0].clientY; currentY = startY; dragging = true; }, { passive: true });
  container.addEventListener('touchmove', e => {
    if (!dragging) return;
    currentY = e.touches[0].clientY;
    const card = document.querySelector('.recipe-card-full.current');
    if (card) { card.classList.add('dragging'); card.style.transform = `translateY(${(currentY-startY)*0.4}px)`; }
  }, { passive: true });
  container.addEventListener('touchend', () => {
    if (!dragging) return;
    dragging = false;
    const dy = currentY - startY;
    document.querySelectorAll('.recipe-card-full').forEach(c => { c.classList.remove('dragging'); c.style.transform = ''; });
    if (dy < -60) feedNext();
    else if (dy > 60) feedPrev();
  });

  document.getElementById('feed-back-btn').addEventListener('click', () => { stopCamera(); showScreen('home'); });
  document.getElementById('feed-filter-btn').addEventListener('click', () => openFilterSheet());
}

function feedNext() {
  const total = state.feedRecipes.length;
  if (state.feedIndex >= total - 1) {
    loadRecipeBatch(state._currentPrompt, 3).then(() => {
      if (state.feedRecipes.length > total) { state.feedIndex++; updateFeedPositions(); }
    });
    return;
  }
  state.feedIndex++;
  updateFeedPositions();
  if (total - 1 - state.feedIndex <= 2) loadRecipeBatch(state._currentPrompt, 3);
}

function feedPrev() {
  if (state.feedIndex > 0) { state.feedIndex--; updateFeedPositions(); }
}

// ==================== NUTRITION ====================
function openNutritionSheet(recipe) {
  if (!recipe) return;
  const nutrition = recipe.nutrition || estimateNutrition(recipe);
  const grid = document.getElementById('nutrition-grid');
  const breakdown = document.getElementById('nutrition-breakdown');

  grid.innerHTML = [
    { label: 'Calories', value: nutrition.calories, unit: 'kcal' },
    { label: 'Protein', value: nutrition.protein, unit: 'g' },
    { label: 'Carbs', value: nutrition.carbs, unit: 'g' },
    { label: 'Fat', value: nutrition.fat, unit: 'g' },
  ].map(n => `
    <div class="nutrition-item">
      <div class="nutrition-value">${n.value}</div>
      <div class="nutrition-unit">${n.unit}</div>
      <div class="nutrition-label">${n.label}</div>
    </div>
  `).join('');

  const totalMacros = nutrition.protein + nutrition.carbs + nutrition.fat;
  breakdown.innerHTML = [
    { label: 'Carbs', value: nutrition.carbs, unit: 'g', cls: 'bar-carbs', pct: Math.round(nutrition.carbs/totalMacros*100) },
    { label: 'Protein', value: nutrition.protein, unit: 'g', cls: 'bar-protein', pct: Math.round(nutrition.protein/totalMacros*100) },
    { label: 'Fat', value: nutrition.fat, unit: 'g', cls: 'bar-fat', pct: Math.round(nutrition.fat/totalMacros*100) },
    { label: 'Fiber', value: nutrition.fiber || '~4', unit: 'g', cls: 'bar-fiber', pct: 30 },
  ].map(row => `
    <div class="nutrition-bar-row">
      <div class="nutrition-bar-label">
        <span>${row.label}</span>
        <span>${row.value}${row.unit}</span>
      </div>
      <div class="nutrition-bar-track">
        <div class="nutrition-bar-fill ${row.cls}" style="width:${row.pct}%"></div>
      </div>
    </div>
  `).join('');

  openSheet('nutrition-sheet');
}

function estimateNutrition(recipe) {
  // Rough heuristic from ingredients/tags
  const tags = (recipe.dietaryTags || []).join(' ').toLowerCase();
  const title = (recipe.title || '').toLowerCase();
  const ings = (recipe.ingredients || []).join(' ').toLowerCase();

  let calories = 480, protein = 28, carbs = 52, fat = 18, fiber = 5;

  if (tags.includes('vegan') || tags.includes('vegetarian')) { calories -= 80; protein -= 8; fat -= 4; }
  if (tags.includes('low-carb')) { carbs = Math.round(carbs * 0.35); calories -= 120; }
  if (ings.includes('chicken') || ings.includes('turkey')) { protein += 10; }
  if (ings.includes('beef') || ings.includes('pork') || ings.includes('lamb')) { protein += 8; fat += 8; calories += 80; }
  if (ings.includes('pasta') || ings.includes('rice') || ings.includes('noodle')) { carbs += 20; calories += 80; }
  if (ings.includes('cream') || ings.includes('butter') || ings.includes('cheese')) { fat += 12; calories += 100; }
  if (ings.includes('fish') || ings.includes('salmon') || ings.includes('tuna')) { protein += 12; fat -= 4; }

  return {
    calories: Math.max(200, calories),
    protein: Math.max(5, protein),
    carbs: Math.max(5, carbs),
    fat: Math.max(3, fat),
    fiber,
  };
}

// ==================== PRINT ====================
function fixSpacing(text) {
  // Fix missing space after periods, commas, colons
  return (text || '')
    .replace(/\.([A-Z])/g, '. $1')
    .replace(/,([^ ])/g, ', $1')
    .replace(/:([^ \n])/g, ': $1');
}

function printRecipe(recipe) {
  const nutrition = recipe.nutrition || estimateNutrition(recipe);
  const win = window.open('', '_blank');
  win.document.write(`<!DOCTYPE html><html><head><title>${recipe.title}</title><meta charset="UTF-8"/>
  <style>
    *{box-sizing:border-box;margin:0;padding:0}
    body{font-family:Georgia,serif;max-width:680px;margin:0 auto;padding:0 24px 40px;color:#1a1a1a;line-height:1.7}
    .top-bar{display:flex;align-items:center;justify-content:space-between;padding:18px 0 14px;border-bottom:1px solid #eee;margin-bottom:24px}
    .back-btn{background:#f5f5f5;border:1px solid #ddd;border-radius:8px;padding:8px 16px;font-size:.85rem;cursor:pointer;font-family:sans-serif;color:#333;text-decoration:none;display:inline-block}
    .back-btn:hover{background:#eee}
    .print-btn{background:#ff5722;border:none;border-radius:8px;padding:8px 16px;font-size:.85rem;cursor:pointer;font-family:sans-serif;color:white}
    .header{border-bottom:3px solid #ff5722;padding-bottom:20px;margin-bottom:24px}
    .header-top{display:flex;align-items:center;gap:14px;margin-bottom:10px}
    .emoji{font-size:2.8rem;line-height:1}
    h1{font-size:1.8rem;font-weight:700;letter-spacing:-0.02em;line-height:1.2}
    .desc{color:#555;font-style:italic;margin-top:6px}
    .tags{display:flex;flex-wrap:wrap;gap:6px;margin-top:10px}
    .tag{background:#fff3f0;border:1px solid #ff5722;border-radius:100px;padding:2px 10px;font-size:.7rem;color:#ff5722;font-family:sans-serif;font-weight:600}
    .nutrition-row{display:flex;gap:10px;margin:20px 0;flex-wrap:wrap}
    .nut-box{background:#fff8f6;border:1px solid #ffd0c0;border-radius:12px;padding:10px 16px;text-align:center;flex:1;min-width:60px}
    .nut-val{font-size:1.4rem;font-weight:800;color:#ff5722;font-family:sans-serif;line-height:1}
    .nut-unit{font-size:.62rem;color:#999;font-family:sans-serif}
    .nut-lbl{font-size:.68rem;font-weight:600;color:#666;text-transform:uppercase;letter-spacing:.05em;font-family:sans-serif;margin-top:3px}
    h2{font-size:.88rem;text-transform:uppercase;letter-spacing:.1em;color:#ff5722;margin:24px 0 12px;font-family:sans-serif;font-weight:700}
    ul.ings{list-style:none}
    ul.ings li{padding:7px 0;border-bottom:1px solid #f0f0f0;font-size:.93rem}
    ul.ings li::before{content:'• ';color:#ff5722;font-weight:700}
    ol.steps{list-style:none;counter-reset:steps}
    ol.steps li{display:flex;gap:14px;padding:11px 0;border-bottom:1px solid #f0f0f0;font-size:.93rem;line-height:1.65}
    .sn{background:#ff5722;color:white;width:26px;height:26px;min-width:26px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:.72rem;font-weight:700;font-family:sans-serif;margin-top:1px}
    .notes li{padding:8px 12px;background:#fff8f6;border-left:3px solid #ff5722;margin-bottom:7px;font-size:.9rem;color:#555;list-style:none;border-radius:0 6px 6px 0}
    .footer{margin-top:36px;padding-top:14px;border-top:1px solid #eee;font-size:.7rem;color:#bbb;font-family:sans-serif}
    @media print{.top-bar{display:none}body{margin:10px}}
  </style></head><body>
  <div class="top-bar">
    <a class="back-btn" onclick="window.close();return false;" href="#">← Close</a>
    <button class="print-btn" onclick="window.print()">Print / Save PDF</button>
  </div>
  <div class="header">
    <div class="header-top">
      <span class="emoji">${recipe.emoji||'🍽️'}</span>
      <h1>${recipe.title}</h1>
    </div>
    <p class="desc">${fixSpacing(recipe.description)}</p>
    ${recipe.dietaryTags?.length?`<div class="tags">${recipe.dietaryTags.map(t=>`<span class="tag">${t}</span>`).join('')}</div>`:''}
  </div>
  <div class="nutrition-row">
    <div class="nut-box"><div class="nut-val">${nutrition.calories}</div><div class="nut-unit">kcal</div><div class="nut-lbl">Calories</div></div>
    <div class="nut-box"><div class="nut-val">${nutrition.protein}</div><div class="nut-unit">g</div><div class="nut-lbl">Protein</div></div>
    <div class="nut-box"><div class="nut-val">${nutrition.carbs}</div><div class="nut-unit">g</div><div class="nut-lbl">Carbs</div></div>
    <div class="nut-box"><div class="nut-val">${nutrition.fat}</div><div class="nut-unit">g</div><div class="nut-lbl">Fat</div></div>
  </div>
  <h2>Ingredients</h2>
  <ul class="ings">${recipe.ingredients.map(i=>`<li>${fixSpacing(i)}</li>`).join('')}</ul>
  <h2>Instructions</h2>
  <ol class="steps">${recipe.steps.map((s,i)=>`<li><span class="sn">${i+1}</span><span>${fixSpacing(s)}</span></li>`).join('')}</ol>
  ${recipe.notes?.length?`<h2>Notes</h2><ul class="notes">${recipe.notes.map(n=>`<li>${fixSpacing(n)}</li>`).join('')}</ul>`:''}
  <div class="footer">Printed from CookFlow &nbsp;·&nbsp; Nutrition estimates per serving</div>
  </body></html>`);
  win.document.close();
}

// ==================== COOK MODE ====================
function startCookMode() {
  if (!state.currentRecipe) return;
  state.cookStep = 0;
  addToHistory(state.currentRecipe);

  const container = document.getElementById('cook-container');
  container.innerHTML = '';
  const recipe = state.currentRecipe;
  document.getElementById('cook-recipe-label').textContent = recipe.title;

  const slides = [
    { type: 'intro', ingredients: recipe.ingredients },
    ...recipe.steps.map((text, i) => ({ type: 'step', num: i+1, text })),
    { type: 'done' },
  ];
  state._cookSlides = slides;
  slides.forEach((slide, i) => container.appendChild(createCookSlide(slide, i, slides.length)));
  renderCookDots(slides.length);
  updateCookPositions();

  document.getElementById('sheet-ingredients-list').innerHTML =
    recipe.ingredients.map(ing => `<li>${ing}</li>`).join('');

  showScreen('cook');
}

function createCookSlide(slide, index, total) {
  const div = document.createElement('div');
  div.className = 'cook-slide';
  div.dataset.index = index;
  if (slide.type === 'intro') {
    div.classList.add('cook-intro-slide');
    div.innerHTML = `<div class="cook-step-num-bg">00</div><div class="cook-step-label">Get Ready</div>
      <div class="cook-step-text">Gather your ingredients and let's cook.</div>
      <ul class="cook-intro-list">${slide.ingredients.map(i=>`<li>${i}</li>`).join('')}</ul>`;
  } else if (slide.type === 'done') {
    div.innerHTML = `<div class="cook-step-num-bg">✓</div><div class="cook-step-label">Complete</div>
      <div class="cook-step-text" style="font-size:1.5rem;font-style:normal;font-weight:700">You're done! Enjoy your meal. 🎉</div>`;
  } else {
    div.innerHTML = `<div class="cook-step-num-bg">${String(slide.num).padStart(2,'0')}</div>
      <div class="cook-step-label">Step ${slide.num} of ${total-2}</div>
      <div class="cook-step-text">${fixSpacing(slide.text)}</div>`;
  }
  return div;
}

function renderCookDots(total) {
  document.getElementById('cook-progress-dots').innerHTML =
    Array.from({length:Math.min(total,10)},(_,i)=>`<div class="cpd" data-dot="${i}"></div>`).join('');
}

function updateCookPositions() {
  document.querySelectorAll('.cook-slide').forEach(s => {
    const i = parseInt(s.dataset.index);
    s.classList.remove('above','current','below','dragging'); s.style.transform='';
    if (i<state.cookStep) s.classList.add('above');
    else if (i===state.cookStep) s.classList.add('current');
    else s.classList.add('below');
  });
  document.querySelectorAll('.cpd').forEach((dot,i) => {
    dot.classList.remove('active','done');
    if (i===state.cookStep) dot.classList.add('active');
    else if (i<state.cookStep) dot.classList.add('done');
  });
  document.getElementById('cook-step-indicator').textContent = `${state.cookStep+1} / ${state._cookSlides.length}`;
}

function bindCookEvents() {
  const container = document.getElementById('cook-container');
  let startY=0, currentY=0;
  container.addEventListener('touchstart', e=>{startY=e.touches[0].clientY;currentY=startY;},{passive:true});
  container.addEventListener('touchmove', e=>{
    currentY=e.touches[0].clientY;
    const s=document.querySelector('.cook-slide.current');
    if(s){s.classList.add('dragging');s.style.transform=`translateY(${(currentY-startY)*.35}px)`;}
  },{passive:true});
  container.addEventListener('touchend',()=>{
    const dy=currentY-startY;
    document.querySelectorAll('.cook-slide').forEach(s=>{s.classList.remove('dragging');s.style.transform='';});
    if(dy<-60)cookAdvance(); else if(dy>60)cookRetreat();
  });
  document.getElementById('cook-exit-btn').addEventListener('click',()=>showScreen('feed'));
  document.getElementById('cook-ingredients-peek').addEventListener('click',()=>openSheet('ingredients-sheet'));
}

function cookAdvance(){if(state.cookStep<state._cookSlides.length-1){state.cookStep++;updateCookPositions();}}
function cookRetreat(){if(state.cookStep>0){state.cookStep--;updateCookPositions();}}

// ==================== REMIX ====================
async function remixRecipe(modification) {
  if (!state.currentRecipe) return;
  closeAllSheets();
  showToast('Remixing...');
  try {
    const filters = Array.from(state.activeFilters);
    const prompt = `Take the recipe "${state.currentRecipe.title}" and ${modification}. Keep the same general dish concept.`;
    const res = await fetch('/api/searchRecipes', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({prompt, filters, count:1}),
    });
    if (!res.ok) throw new Error('failed');
    const data = await res.json();
    const recipe = data.recipes?.[0];
    if (!recipe) throw new Error('empty');
    recipe.emoji = randomEmoji();
    recipe.bgColor = BG_COLORS[Math.floor(Math.random()*BG_COLORS.length)];
    recipe._prompt = state.currentRecipe._prompt;
    recipe._source = data.source;
    state.feedRecipes[state.feedIndex] = recipe;
    state.currentRecipe = recipe;
    renderFeedCards();
    showToast('Remixed! ✓');
  } catch(err){ console.error(err); showToast('Remix failed. Try again!'); }
}

// ==================== PANTRY ====================
function bindPantryEvents() {
  document.getElementById('pantry-go-btn').addEventListener('click', () => {
    const text = document.getElementById('pantry-textarea').value.trim();
    if (!text) { showToast('Add some ingredients first!'); return; }
    startFeedWithPrompt(`recipes using these ingredients: ${text}`);
  });
}

// ==================== FRIDGE SCAN ====================
function bindFridgeEvents() {
  document.getElementById('fridge-close-btn').addEventListener('click',()=>{stopCamera();showScreen('home');});
  document.getElementById('cam-flip-btn').addEventListener('click',()=>{
    state.cameraFacing=state.cameraFacing==='environment'?'user':'environment';
    stopCamera(); startCamera();
  });
  document.getElementById('shutter-btn').addEventListener('click', capturePhoto);
}
async function openFridgeScan(){showScreen('fridge');await startCamera();}
async function startCamera(){
  try{
    const stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:state.cameraFacing,width:{ideal:1280},height:{ideal:720}},audio:false});
    state.cameraStream=stream;
    document.getElementById('camera-video').srcObject=stream;
  }catch(err){console.error(err);showToast('Camera access denied.');showScreen('home');}
}
function stopCamera(){
  if(state.cameraStream){state.cameraStream.getTracks().forEach(t=>t.stop());state.cameraStream=null;}
  document.getElementById('camera-video').srcObject=null;
}
async function capturePhoto(){
  const video=document.getElementById('camera-video');
  const canvas=document.getElementById('camera-canvas');
  canvas.width=video.videoWidth||640; canvas.height=video.videoHeight||480;
  canvas.getContext('2d').drawImage(video,0,0);
  const base64=canvas.toDataURL('image/jpeg',0.85).split(',')[1];
  document.getElementById('scan-overlay').classList.remove('hidden');
  try{
    const res=await fetch('/api/scanFridge',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({image:base64})});
    if(!res.ok) throw new Error(`${res.status}`);
    const data=await res.json();
    if(!data.ingredients?.length){showToast('No ingredients detected. Try a clearer photo!');return;}
    state.detectedIngredients=[...data.ingredients];
    stopCamera();
    renderIngredientConfirm(data.ingredients);
    showScreen('ingredients-confirm');
  }catch(err){console.error(err);showToast('Scan failed. Try again!');}
  finally{document.getElementById('scan-overlay').classList.add('hidden');}
}

// ==================== INGREDIENT CONFIRM ====================
function renderIngredientConfirm(ingredients){
  document.getElementById('ingredient-chips-wrap').innerHTML='';
  ingredients.forEach(ing=>addIngredientChip(ing));
}
function addIngredientChip(ing){
  const wrap=document.getElementById('ingredient-chips-wrap');
  const chip=document.createElement('div');
  chip.className='ingredient-chip';
  chip.innerHTML=`<span>${ing}</span><span class="chip-x">✕</span>`;
  chip.addEventListener('click',()=>{const idx=state.detectedIngredients.indexOf(ing);if(idx>-1)state.detectedIngredients.splice(idx,1);chip.remove();});
  wrap.appendChild(chip);
}
function bindIngredientConfirmEvents(){
  document.getElementById('add-ingredient-btn').addEventListener('click',()=>{
    const input=document.getElementById('add-ingredient-input');
    const val=input.value.trim(); if(!val)return;
    state.detectedIngredients.push(val); addIngredientChip(val); input.value='';
  });
  document.getElementById('add-ingredient-input').addEventListener('keydown',e=>{if(e.key==='Enter')document.getElementById('add-ingredient-btn').click();});
  document.getElementById('confirm-generate-btn').addEventListener('click',()=>{
    const ings=state.detectedIngredients;
    if(!ings.length){showToast('Add at least one ingredient!');return;}
    startFeedWithPrompt(`recipes using these ingredients: ${ings.join(', ')}`);
  });
}

// ==================== SAVED ====================
function getSavedRecipes(){try{return JSON.parse(localStorage.getItem('cf3_saved')||'[]');}catch{return [];}}
function isRecipeSaved(recipe){return getSavedRecipes().some(r=>r.title===recipe.title);}
function toggleSaveRecipe(recipe){
  const saved=getSavedRecipes();
  const idx=saved.findIndex(r=>r.title===recipe.title);
  if(idx>-1){saved.splice(idx,1);showToast('Removed from saved.');}
  else{saved.unshift({...recipe,savedAt:Date.now()});showToast('Saved! ✓');}
  localStorage.setItem('cf3_saved',JSON.stringify(saved));
}
function renderSavedScreen(){
  const saved=getSavedRecipes();
  const list=document.getElementById('saved-list');
  const empty=document.getElementById('saved-empty');
  list.innerHTML='';
  if(!saved.length){empty.classList.remove('hidden');return;}
  empty.classList.add('hidden');
  saved.forEach(recipe=>{
    const card=document.createElement('div');
    card.className='saved-card';
    card.innerHTML=`
      <div class="saved-card-emoji">${recipe.emoji||'🍽️'}</div>
      <div class="saved-card-info">
        <div class="saved-card-title">${recipe.title}</div>
        <div class="saved-card-desc">${recipe.description}</div>
      </div>
      <div style="display:flex;gap:5px;flex-shrink:0">
        <button class="saved-card-delete print-btn" title="Print">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect x="6" y="14" width="12" height="8"/></svg>
        </button>
        <button class="saved-card-delete del-btn" title="Remove">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </button>
      </div>`;
    card.querySelector('.del-btn').addEventListener('click',e=>{e.stopPropagation();toggleSaveRecipe(recipe);renderSavedScreen();});
    card.querySelector('.print-btn').addEventListener('click',e=>{e.stopPropagation();printRecipe(recipe);});
    card.addEventListener('click',()=>{
      state.feedRecipes=[{...recipe,bgColor:recipe.bgColor||BG_COLORS[0]}];
      state.feedIndex=0; showScreen('feed'); renderFeedCards();
    });
    list.appendChild(card);
  });
}

// ==================== SHEETS ====================
function openSheet(id){document.getElementById(id).classList.remove('hidden');document.getElementById('sheet-backdrop').classList.remove('hidden');}
function closeAllSheets(){document.querySelectorAll('.bottom-sheet').forEach(s=>s.classList.add('hidden'));document.getElementById('sheet-backdrop').classList.add('hidden');}
function openRemixSheet(){openSheet('remix-sheet');}

function openFilterSheet(){
  const grid=document.getElementById('sheet-filters-grid');
  grid.innerHTML='';
  const FILTERS=['vegetarian','vegan','gluten-free','dairy-free','nut-free','shellfish-free','low-carb','halal','kosher'];
  const LABELS={'vegetarian':'🌿 Vegetarian','vegan':'🌱 Vegan','gluten-free':'🌾 Gluten-Free','dairy-free':'🥛 Dairy-Free','nut-free':'🥜 Nut-Free','shellfish-free':'🦐 Shellfish-Free','low-carb':'📉 Low-Carb','halal':'☪️ Halal','kosher':'✡️ Kosher'};
  FILTERS.forEach(f=>{
    const pill=document.createElement('button');
    pill.className='filter-pill'+(state.activeFilters.has(f)?' active':'');
    pill.textContent=LABELS[f];
    pill.addEventListener('click',()=>{
      if(state.activeFilters.has(f)){state.activeFilters.delete(f);pill.classList.remove('active');}
      else{state.activeFilters.add(f);pill.classList.add('active');}
      saveFilters();syncHomeFilterPills();
    });
    grid.appendChild(pill);
  });
  openSheet('filter-sheet');
}

function bindSheetEvents(){
  document.getElementById('sheet-backdrop').addEventListener('click',closeAllSheets);
  document.getElementById('sheet-close-btn').addEventListener('click',closeAllSheets);
  document.getElementById('nutrition-close-btn').addEventListener('click',closeAllSheets);
  document.getElementById('remix-close-btn').addEventListener('click',closeAllSheets);
  document.querySelectorAll('.remix-chip').forEach(chip=>chip.addEventListener('click',()=>remixRecipe(chip.dataset.mod)));
  document.getElementById('remix-custom-go').addEventListener('click',()=>{
    const val=document.getElementById('remix-custom-input').value.trim();
    if(val)remixRecipe(val);
  });
  document.getElementById('remix-custom-input').addEventListener('keydown',e=>{if(e.key==='Enter')document.getElementById('remix-custom-go').click();});
  document.getElementById('filter-apply-btn').addEventListener('click',()=>{
    closeAllSheets();
    if(document.getElementById('screen-feed').classList.contains('active')&&state._currentPrompt)startFeedWithPrompt(state._currentPrompt);
    showToast('Filters updated!');
  });
}

// ==================== FILTERS ====================
function saveFilters(){localStorage.setItem('cf3_filters',JSON.stringify([...state.activeFilters]));syncHomeFilterPills();}
function restoreFilters(){try{const s=JSON.parse(localStorage.getItem('cf3_filters')||'[]');s.forEach(f=>state.activeFilters.add(f));syncHomeFilterPills();}catch{}}
function syncHomeFilterPills(){document.querySelectorAll('#filters-grid .filter-pill').forEach(p=>p.classList.toggle('active',state.activeFilters.has(p.dataset.filter)));}

// ==================== TOAST ====================
function showToast(msg){
  const toast=document.getElementById('toast');
  toast.textContent=msg; toast.classList.remove('hidden'); toast.classList.add('show');
  clearTimeout(toast._t);
  toast._t=setTimeout(()=>{toast.classList.remove('show');setTimeout(()=>toast.classList.add('hidden'),320);},2800);
}

function randomEmoji(){return FOOD_EMOJIS[Math.floor(Math.random()*FOOD_EMOJIS.length)];}
